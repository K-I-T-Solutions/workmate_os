# 🧩 Core Entity-Relationship Model

Das folgende DBML beschreibt das komplette Core-Schema.

```dbml
{{ hier dein bereinigter core_erm.dbml code }}
```

> 🔍 Kann direkt bei [dbdiagram.io](https://dbdiagram.io) eingefügt werden, um das Diagramm visuell anzuzeigen.
